#!/bin/bash

# FacebookPro Blaster - One Click Setup for Linux
# This script will automatically setup everything you need

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

section_line() {
    echo -e "${CYAN}------------------------------------------------------------${NC}"
}

print_step() {
    section_line
    echo -e "${CYAN}$1${NC}"
    section_line
}

print_ok() {
    echo -e "${GREEN}[OK] $1${NC}"
}

print_warn() {
    echo -e "${YELLOW}[WARN] $1${NC}"
}

print_info() {
    echo -e "${CYAN}[INFO] $1${NC}"
}

print_error() {
    echo -e "${RED}[ERROR] $1${NC}"
}

section_line
echo -e "${CYAN}FACEBOOKPRO BLASTER - ONE CLICK SETUP (Brave Edition)${NC}"
section_line
echo ""

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
    print_warn "Please do not run this script as root"
    echo -e "${YELLOW}   Run as normal user (script will ask for sudo when needed)${NC}"
    exit 1
fi

print_ok "Starting automated setup..."
echo ""

# Set BROWSER_ENGINE to playwright-brave
BROWSER_ENGINE="playwright-brave"
echo -e "${CYAN}[*] System engine: Playwright + Brave (Aggressive Adblocking)${NC}"

echo ""

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
else
    OS=$(uname -s)
fi

print_info "Detected OS: $OS"
echo ""

# 1. Check and Install Node.js

print_step "STEP 1: Node.js Installation"


if command_exists node; then
    NODE_VERSION=$(node --version)
    print_ok "Node.js already installed: $NODE_VERSION"
else
    print_warn "Installing Node.js LTS..."
    
    case "$OS" in
        ubuntu|debian)
            echo -e "${YELLOW}   Using apt package manager...${NC}"
            curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
            sudo apt-get install -y nodejs
            ;;
        fedora|rhel|centos)
            echo -e "${YELLOW}   Using dnf/yum package manager...${NC}"
            curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
            sudo dnf install -y nodejs || sudo yum install -y nodejs
            ;;
        arch|manjaro)
            echo -e "${YELLOW}   Using pacman package manager...${NC}"
            sudo pacman -S --noconfirm nodejs npm
            ;;
        *)
            print_error "Unsupported OS: $OS"
            echo -e "${YELLOW}   Please install Node.js manually from: https://nodejs.org${NC}"
            exit 1
            ;;
    esac
    
    if command_exists node; then
        print_ok "Node.js installed successfully!"
    else
        print_error "Node.js installation failed"
        exit 1
    fi
fi

echo ""


# 2. Check and Install Python 3.12

print_step "STEP 2: Python 3.12 Installation"


if command_exists python3.12; then
    PY_VERSION=$(python3.12 --version)
    print_ok "Python 3.12 already installed: $PY_VERSION"
else
    print_warn "Installing Python 3.12..."
    
    case "$OS" in
        ubuntu|debian)
            echo -e "${YELLOW}   Using apt package manager...${NC}"
            sudo apt-get update
            sudo apt-get install -y software-properties-common
            sudo add-apt-repository -y ppa:deadsnakes/ppa
            sudo apt-get update
            sudo apt-get install -y python3.12 python3.12-venv python3.12-dev python3-pip
            ;;
        *)
            print_warn "Please install Python 3.12 manually for your OS"
            echo -e "${YELLOW}   Face Swap feature might not work without it.${NC}"
            ;;
    esac
fi

# Install Python Dependencies
if command_exists python3.12; then
    print_warn "Installing Python dependencies (InsightFace)..."
    # Ensure pip is installed (especially for Ubuntu 24.04+)
    if ! python3.12 -m pip --version &> /dev/null; then
        print_warn "Pip not found for Python 3.12, attempting to install..."
        sudo apt-get update && sudo apt-get install -y python3-pip python3-venv
    fi

    # Upgrade pip via module to avoid conflicts
    python3.12 -m pip install --upgrade pip --break-system-packages 2>/dev/null || true
    python3.12 -m pip install insightface onnxruntime opencv-python gdown --break-system-packages
    
    if [ $? -eq 0 ]; then
        print_ok "Python dependencies installed!"
        
        # Download Face Swap Model
        print_warn "Downloading Face Swap Model (inswapper_128.onnx)..."
        echo -e "   This file is ~55MB, please wait."
        
        # Create bot directory if it doesn't exist
        mkdir -p bot
        
        # Check if model already exists
        if [ ! -f "bot/inswapper_128.onnx" ]; then
            # Attempt 1: gdown via python
            python3.12 -m gdown "1krOLgjW2tAPaqV-Bw4YALz0xT5zlb5HF" --fuzzy -O bot/inswapper_128.onnx --break-system-packages 2>/dev/null || \
            python3.12 -m gdown "1krOLgjW2tAPaqV-Bw4YALz0xT5zlb5HF" -O bot/inswapper_128.onnx || true
            
            # Fallback 1: wget
            if [ ! -f "bot/inswapper_128.onnx" ]; then
                 echo -e "   ${YELLOW}Attempting direct download via wget...${NC}"
                 wget --quiet --show-progress "https://docs.google.com/uc?export=download&id=1krOLgjW2tAPaqV-Bw4YALz0xT5zlb5HF" -O bot/inswapper_128.onnx || true
            fi
            
            # Fallback 2: curl
            if [ ! -f "bot/inswapper_128.onnx" ]; then
                 echo -e "   ${YELLOW}Attempting direct download via curl...${NC}"
                 curl -L "https://docs.google.com/uc?export=download&id=1krOLgjW2tAPaqV-Bw4YALz0xT5zlb5HF" -o bot/inswapper_128.onnx || true
            fi

            # Final Check
            if [ -f "bot/inswapper_128.onnx" ]; then
                 print_ok "Face Swap Model downloaded successfully!"
            else
                 print_error "Failed to download Face Swap Model automatically."
                 echo -e "${YELLOW}   Please download it manually and place it in the 'bot' folder.${NC}"
                 echo -e "   Download: https://github.com/scwhhhhg/fbpro-blaster/releases/download/assets/inswapper_128.onnx"
            fi
        else
             print_ok "Face Swap Model already exists!"
        fi

    else
        print_error "Failed to install Python dependencies"
    fi
else
    print_error "Python 3.12 not found. Skipping dependency installation."
fi

echo ""

# 3. Install Additional Dependencies

print_step "STEP 3: System Dependencies"


print_warn "Installing required system packages..."

case "$OS" in
    ubuntu|debian)
        sudo apt-get update
        # Puppeteer and system dependencies (with 24.04 t64 transition handling)
        PACKAGES=(
            build-essential git libcairo2-dev libpango1.0-dev libjpeg-dev libgif-dev librsvg2-dev 
            curl wget ca-certificates fonts-liberation libappindicator3-1 
            libatk-bridge2.0-0 libc6 libcairo2 libcups2 libdbus-1-3 libexpat1 
            libfontconfig1 libgbm1 libglib2.0-0 libgtk-3-0 libnspr4 libnss3 
            libstdc++6 libx11-6 libx11-xcb1 libxcb1 libxcomposite1 
            libxcursor1 libxdamage1 libxext6 libxfixes3 libxi6 libxrandr2 
            libxrender1 libxss1 libxtst6 lsb-release xdg-utils
            libpango-1.0-0 libpangocairo-1.0-0
        )

        # Handle version-specific package names
        if [[ "$(lsb_release -rc)" == *"noble"* ]] || [[ "$(lsb_release -rs)" == "24.04" ]]; then
            PACKAGES+=(libasound2t64 libatk1.0-0t64 libgcc-s1)
        else
            PACKAGES+=(libasound2 libatk1.0-0 libgcc1)
        fi

        sudo apt-get install -y "${PACKAGES[@]}" \
            libdrm2 \
            libxkbcommon0 \
            libgbm-dev
        ;;
    fedora|rhel|centos)
        sudo dnf install -y \
            gcc-c++ \
            git \
            make \
            cairo-devel \
            pango-devel \
            libjpeg-turbo-devel \
            giflib-devel \
            curl \
            wget \
            ca-certificates \
            liberation-fonts \
            alsa-lib \
            atk \
            at-spi2-atk \
            cups-libs \
            dbus-libs \
            expat \
            fontconfig \
            glib2 \
            gtk3 \
            libdrm \
            libgbm \
            libX11 \
            libXcomposite \
            libXcursor \
            libXdamage \
            libXext \
            libXfixes \
            libXi \
            libXrandr \
            libXrender \
            libxcb \
            libXScrnSaver \
            libXtst \
            mesa-libgbm \
            nspr \
            nss \
            nss-util \
            xdg-utils || \
        sudo yum install -y \
            gcc-c++ \
            make \
            cairo-devel \
            pango-devel \
            libjpeg-turbo-devel \
            giflib-devel \
            curl \
            wget \
            ca-certificates \
            liberation-fonts \
            alsa-lib \
            atk \
            at-spi2-atk \
            cups-libs \
            dbus-libs \
            expat \
            fontconfig \
            glib2 \
            gtk3 \
            libdrm \
            libgbm \
            libX11 \
            libXcomposite \
            libXcursor \
            libXdamage \
            libXext \
            libXfixes \
            libXi \
            libXrandr \
            libXrender \
            libxcb \
            libXScrnSaver \
            libXtst \
            mesa-libgbm \
            nspr \
            nss \
            nss-util \
            xdg-utils
        ;;
    arch|manjaro)
        sudo pacman -S --noconfirm \
            base-devel \
            cairo \
            pango \
            libjpeg-turbo \
            giflib \
            curl \
            wget \
            ca-certificates \
            ttf-liberation \
            alsa-lib \
            at-spi2-atk \
            atk \
            cups \
            dbus \
            expat \
            fontconfig \
            glib2 \
            gtk3 \
            libdrm \
            libgbm \
            libx11 \
            libxcomposite \
            libxcursor \
            libxdamage \
            libxext \
            libxfixes \
            libxi \
            libxrandr \
            libxrender \
            libxcb \
            libxscrnsaver \
            libxtst \
            mesa \
            nspr \
            nss \
            xdg-utils
        ;;
esac

print_ok "System dependencies installed!"
echo ""

# 4. Prepare Folders

print_step "STEP 4: Preparing Folders"


FOLDERS=(
    "accounts"
    "videos"
    "photos"
    "logs"
    "logs/scheduler"
    "logs/telegram"
    "logs/maintenance"
    "logs/executor"
    "backups"
    "downloads"
    "temp"
    "data"
    "scheduler"
)

for folder in "${FOLDERS[@]}"; do
    if [ ! -d "$folder" ]; then
        mkdir -p "$folder"
        print_ok "Created: $folder/"
    else
        print_ok "Exists: $folder/"
    fi
done

echo ""

# 5. Install Node Dependencies

print_step "STEP 5: Installing Node Dependencies"


if [ -f "package.json" ]; then
    print_warn "Running npm install (this may take several minutes)..."
    echo ""
    
    npm install
    
    echo ""
    print_ok "Dependencies installed successfully!"
else
    print_warn "package.json not found, skipping npm install"
fi

echo ""

# Install scheduler dependencies
print_warn "Installing scheduler dependencies..."
npm install node-cron --save

if [ $? -eq 0 ]; then
    print_ok "node-cron installed successfully!"
else
    print_warn "Failed to install node-cron (optional)"
fi

echo ""

# 6. Install Browser Engine (Brave + Playwright)

print_step "STEP 6: Installing Brave Browser Engine"


# Check for Brave
if command_exists brave-browser; then
    print_ok "Brave Browser already installed: $(brave-browser --version)"
else
    print_warn "Installing Brave Browser..."
    case "$OS" in
        ubuntu|debian)
            sudo apt-get install -y curl
            sudo curl -fsSLo /usr/share/keyrings/brave-browser-archive-keyring.gpg https://brave-browser-apt-release.s3.brave.com/brave-browser-archive-keyring.gpg
            echo "deb [signed-by=/usr/share/keyrings/brave-browser-archive-keyring.gpg] https://brave-browser-apt-release.s3.brave.com/ stable main"|sudo tee /etc/apt/sources.list.d/brave-browser-release.list
            sudo apt-get update
            sudo apt-get install -y brave-browser
            ;;
        fedora)
            sudo dnf install -y dnf-plugins-core
            sudo dnf config-manager --add-repo https://brave-browser-rpm-release.s3.brave.com/brave-browser.repo
            sudo rpm --import https://brave-browser-rpm-release.s3.brave.com/brave-core.asc
            sudo dnf install -y brave-browser
            ;;
        arch|manjaro)
            echo -e "${YELLOW}   Arch users: Please install brave-bin via AUR (e.g., yay -S brave-bin)${NC}"
            ;;
        *)
            print_warn "Could not install Brave automatically for $OS. Please install it manually."
            ;;
    esac
fi

print_warn "Installing Playwright core dependencies..."
npx playwright install chromium --with-deps

if [ $? -eq 0 ]; then
    print_ok "Playwright installed successfully!"
else
    print_warn "Playwright installation finished with warnings."
fi

# 7. Install PM2

print_step "STEP 7: Installing PM2"


if command_exists pm2; then
    PM2_VERSION=$(pm2 --version)
    print_ok "PM2 already installed: v$PM2_VERSION"
else
    print_warn "Installing PM2 globally..."
    sudo npm install -g pm2
    
    if command_exists pm2; then
        print_ok "PM2 installed successfully!"
        echo -e "${CYAN}   Setting up PM2 startup script...${NC}"
        pm2 startup | grep -E '^sudo' | bash || true
    else
        print_warn "PM2 installation failed"
    fi
fi

echo ""

# 8. Set Permissions

print_step "STEP 8: Setting Permissions"


# Make scripts executable
if [ -d "bot" ]; then
    print_warn "Setting executable permissions for bot scripts..."
    
    # Set executable permission for main executables (extension-less files)
    chmod +x bot/executor 2>/dev/null && print_ok "executor" || print_warn "executor not found"
    chmod +x bot/scheduler-cli 2>/dev/null && print_ok "scheduler-cli" || print_warn "scheduler-cli not found"
    chmod +x bot/executor_wrapper.sh 2>/dev/null && print_ok "executor_wrapper.sh" || print_warn "executor_wrapper.sh not found"
    
    # Make all .sh scripts executable
    chmod +x bot/*.sh 2>/dev/null || true
    print_ok "Shell scripts"
    
    echo ""
    print_info "Verifying executable permissions:"
    ls -la bot/executor bot/scheduler-cli bot/executor_wrapper.sh 2>/dev/null | grep -E "^-" || echo -e "${YELLOW}   (Some files not found - will be created by build)${NC}"
fi

# Set folder permissions
chmod 755 accounts videos photos logs backups downloads temp data scheduler 2>/dev/null || true
print_ok "Folder permissions set"

echo ""

# 9. Check License

print_step "STEP 9: License Activation"


if [ -f "bot/.license" ]; then
    print_ok "License already activated!"
else
    print_warn "No license found"
    echo ""
    echo -e "${CYAN}To activate your license, run:${NC}"
    echo -e "   ${NC}npm run activate YOUR_LICENSE_KEY${NC}"
    echo ""
    echo -e "${NC}License format: FBPROBLASTER_XXXX_XXXX_0001_TIER${NC}"
fi

echo ""

# 8. Success Summary
section_line
echo -e "${GREEN}SETUP COMPLETED SUCCESSFULLY!${NC}"
section_line
echo ""

print_info "NEXT STEPS:"
echo ""

echo -e "${YELLOW}1. Activate License:${NC}"
echo -e "   ${NC}npm run activate YOUR_LICENSE_KEY${NC}"
echo ""

echo -e "${YELLOW}2. Brave Adblock Warm-up:${NC}"
echo -e "   ${NC}Runs automatically and globally on first bot launch.${NC}"
echo ""

echo -e "${YELLOW}3. Run a Bot:${NC}"
echo -e "   ${NC}node bot/executor run autolike YOUR_ACCOUNT_ID${NC}"
echo ""

print_info "Documentation:"
echo -e "   ${NC}- README.md${NC}"
echo -e "   ${NC}- LICENSE_ACTIVATION_GUIDE.md${NC}"
echo -e "   ${NC}- INTEGRATED_LICENSE_SYSTEM.md${NC}"
echo ""

echo -e "${GREEN}[DONE] You're all set! Happy automating!${NC}"
echo ""
