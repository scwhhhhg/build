# FacebookPro Blaster - One Click Setup for Windows
# This script will automatically setup everything you need

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue" # Speeds up Invoke-WebRequest significantly

# Get the directory where this script is located
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Self-elevate the script if required
if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
    if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
        Write-Host "Requesting Administrator privileges..." -ForegroundColor Yellow
        
        # Prefer pwsh (PowerShell Core) if available
        $ShellExe = "PowerShell.exe"
        if (Get-Command pwsh -ErrorAction SilentlyContinue) {
            $ShellExe = "pwsh.exe"
        }
        
        # Preserve the working directory by setting it explicitly
        $CommandLine = "-NoExit -Command `"Set-Location '$ScriptDir'; & '$($MyInvocation.MyCommand.Path)'`""
        Start-Process -FilePath $ShellExe -Verb Runas -ArgumentList $CommandLine
        Exit
    }
}

# Ensure we're in the script directory
Set-Location $ScriptDir

# Modern PS check
$isModern = ($PSVersionTable.PSVersion.Major -ge 7)

Clear-Host
Write-Host "" 
Write-Host " ==============================================================" -ForegroundColor Cyan
Write-Host "   FBPro Blaster - Windows Setup (Brave Edition)" -ForegroundColor Cyan
Write-Host " ==============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  [*] PowerShell: $($PSVersionTable.PSVersion.Major).$($PSVersionTable.PSVersion.Minor)" -ForegroundColor Gray -NoNewline
if ($isModern) {
    Write-Host " [Modern Core]" -ForegroundColor Green
} else {
    Write-Host " [Legacy Shell]" -ForegroundColor Yellow
}
Write-Host "  [*] Privileges: Elevated (Administrator)" -ForegroundColor Green
Write-Host ""

# Default engine is now Playwright + Brave
$script:BROWSER_ENGINE = "playwright-brave"
Write-Host "  [*] Engine: Playwright + Brave Browser (Aggressive Adblocking)" -ForegroundColor Cyan
Write-Host ""

# Function to Download Face Swap Model
function Download-FaceSwapModel {
    param($pythonExec, $destDir)
    
    $botDir = Join-Path $destDir "bot"
    if (-not (Test-Path $botDir)) {
        New-Item -ItemType Directory -Path $botDir -Force | Out-Null
    }
    $modelPath = Join-Path $botDir "inswapper_128.onnx"
    
    # Check if exists and is valid size (approx 55MB)
    if (Test-Path $modelPath) {
        $file = Get-Item $modelPath
        if ($file.Length -lt 50MB) {
            Write-Host " [!] Existing model file is too small ($($file.Length / 1KB) KB), re-downloading..." -ForegroundColor Yellow
            Remove-Item $modelPath -Force
        }
    }

    if (-not (Test-Path $modelPath)) {
        Write-Host " [*] Downloading Face Swap Model (inswapper_128.onnx)..." -ForegroundColor Yellow
        Write-Host "     This file is ~55MB, please wait." -ForegroundColor Gray
        
        # Try GitHub Direct Link first (More reliable for scripts)
        try {
            $githubUrl = "https://github.com/scwhhhhg/fbpro-blaster/releases/download/assets/inswapper_128.onnx"
            Write-Host "     [*] Attempting download from GitHub..." -ForegroundColor Gray
            Invoke-WebRequest -Uri $githubUrl -OutFile "$modelPath" -UseBasicParsing -TimeoutSec 300
        } catch { }

        # Fallback 1: Google Drive via gdown
        if (-not (Test-Path $modelPath) -or (Get-Item $modelPath).Length -lt 50MB) {
            try {
                if ($null -ne $pythonExec) {
                    Write-Host "     [*] GitHub failed, trying gdown..." -ForegroundColor Gray
                    if (Test-Path $modelPath) { Remove-Item $modelPath -Force }
                    $null = & $pythonExec -m gdown "1krOLgjW2tAPaqV-Bw4YALz0xT5zlb5HF" --fuzzy -O "$modelPath"
                }
            } catch { }
        }

        # Fallback 2: Google Drive via Direct Web Request (handling large file warning)
        if (-not (Test-Path $modelPath) -or (Get-Item $modelPath).Length -lt 50MB) {
            Write-Host "     [*] gdown failed, trying direct Google Drive download..." -ForegroundColor Yellow
            try {
                if (Test-Path $modelPath) { Remove-Item $modelPath -Force }
                $id = "1krOLgjW2tAPaqV-Bw4YALz0xT5zlb5HF"
                # This construct handles the "Google Drive can't scan this file for viruses" confirmation
                $url = "https://docs.google.com/uc?export=download&id=$id&confirm=t"
                Invoke-WebRequest -Uri $url -OutFile "$modelPath" -UseBasicParsing -UserAgent "Mozilla/5.0"
            } catch {
                Write-Host "     [!] Direct download failed: $_" -ForegroundColor Red
            }
        }

        if (Test-Path $modelPath) {
            $finalFile = Get-Item $modelPath
            if ($finalFile.Length -ge 50MB) {
                Write-Host " [+] Face Swap Model downloaded successfully! ($($finalFile.Length / 1MB) MB)" -ForegroundColor Green
            } else {
                Write-Host " [-] Downloaded file is too small ($($finalFile.Length / 1KB) KB). Download failed." -ForegroundColor Red
                Remove-Item $modelPath -Force
            }
        } else {
            Write-Host " [-] Failed to download Face Swap Model automatically." -ForegroundColor Red
            Write-Host "     Please download manually from: https://github.com/scwhhhhg/fbpro-blaster/releases/download/assets/inswapper_128.onnx" -ForegroundColor Yellow
            Write-Host "     and save it as: $modelPath" -ForegroundColor Yellow
        }
    } else {
        Write-Host " [+] Face Swap Model already exists and is valid size." -ForegroundColor Green
    }
}

# Function to check if command exists
function Test-CommandExists {
    param($command)
    $null = Get-Command $command -ErrorAction SilentlyContinue
    return $?
}

# STEP 1: Check and Install Node.js  
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "STEP 1: Node.js Installation" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan

if (Test-CommandExists node) {
    $nodeVersion = node --version
    Write-Host "[+] Node.js already installed: $nodeVersion" -ForegroundColor Green
} else {
    Write-Host "[*] Downloading Node.js LTS..." -ForegroundColor Yellow
    
    $nodeUrl = "https://nodejs.org/dist/v20.11.0/node-v20.11.0-x64.msi"
    $nodeInstaller = "$env:TEMP\nodejs-installer.msi"
    
    try {
        Write-Host "[*] Connecting to nodejs.org..." -ForegroundColor Gray
        Invoke-WebRequest -Uri $nodeUrl -OutFile $nodeInstaller -UseBasicParsing -TimeoutSec 300
        Write-Host "[*] Installing Node.js (this may take a few minutes)..." -ForegroundColor Yellow
        Start-Process msiexec.exe -ArgumentList "/i `"$nodeInstaller`" /quiet /norestart" -Wait
        
        # Refresh environment variables
        $machinePath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
        $userPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
        $env:Path = $machinePath + ";" + $userPath
        
        Write-Host "[+] Node.js installed successfully!" -ForegroundColor Green
        Remove-Item $nodeInstaller -Force
    } catch {
        Write-Host "[-] Failed to install Node.js: $_" -ForegroundColor Red
        Write-Host "    Please install manually from: https://nodejs.org" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
}


Write-Host ""

# STEP 1.5: Check and Install Python 3.12
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "STEP 1.5: Python 3.12 Installation (Required for Face Swap)" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan

$pythonCmd = $null

# Function to verify if a python path is actually functional
function Verify-Python {
    param($path)
    try {
        $v = & $path --version 2>&1
        if ($LASTEXITCODE -eq 0 -and $v -match "Python") {
            # Ensure it's not the broken App Store alias
            if ($path -eq "python" -or $path -eq "py") {
                $fullPath = (Get-Command $path -ErrorAction SilentlyContinue).Source
                if ($fullPath -match "WindowsApps\\python.exe") { return $false }
            }
            return $true
        }
    } catch { }
    return $false
}

# 1. Try commands in PATH
if (Verify-Python "python") { $pythonCmd = "python" }
elseif (Verify-Python "py") { $pythonCmd = "py" }

# 2. Try common installation paths if still not found
if ($null -eq $pythonCmd) {
    $searchPaths = @(
        "C:\Program Files\Python312\python.exe",
        "C:\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "C:\Program Files\Python311\python.exe",
        "C:\Python311\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "C:\Program Files\Python310\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe"
    )
    foreach ($path in $searchPaths) {
        if (Test-Path $path) {
            if (Verify-Python $path) {
                $pythonCmd = $path
                break
            }
        }
    }
}

if ($null -ne $pythonCmd) {
    try {
        $pyVersion = & $pythonCmd --version 2>&1
        Write-Host "[+] Python already installed: $pyVersion" -ForegroundColor Green
        if ($pythonCmd -match ":\\") {
            Write-Host "    (Found at: $pythonCmd)" -ForegroundColor Gray
            # Add to path for current session if it's a direct path
            $pyDir = Split-Path $pythonCmd
            $scriptsDir = Join-Path $pyDir "Scripts"
            $env:Path = "$pyDir;$scriptsDir;" + $env:Path
        }
        
        # Check if pip works
        Write-Host "[*] Upgrading pip..." -ForegroundColor Yellow
        & $pythonCmd -m pip install --upgrade pip
        
        Write-Host "[*] Installing Face Swap dependencies (InsightFace)..." -ForegroundColor Yellow
        & $pythonCmd -m pip install insightface onnxruntime opencv-python gdown
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[+] Python dependencies installed!" -ForegroundColor Green
            Download-FaceSwapModel -pythonExec $pythonCmd -destDir $ScriptDir
        } else {
            Write-Host "[-] Failed to install Python dependencies. Please install 'insightface onnxruntime opencv-python' manually." -ForegroundColor Red
        }
    } catch {
        Write-Host "[-] Error checking Python or dependencies: $_" -ForegroundColor Yellow
    }
} else {
    Write-Host "[*] Downloading Python 3.12..." -ForegroundColor Yellow
    
    $pyUrl = "https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe"
    $pyInstaller = "$env:TEMP\python-installer.exe"
    
    try {
        Write-Host "[*] Connecting to python.org..." -ForegroundColor Gray
        Invoke-WebRequest -Uri $pyUrl -OutFile $pyInstaller -UseBasicParsing -TimeoutSec 300
        Write-Host "[*] Installing Python 3.12 (Silent Mode)..." -ForegroundColor Yellow
        
        # Install Python silently with Path enabled
        Start-Process -FilePath $pyInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait
        
        # Refresh environment variables aggressively
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-Host "[+] Python 3.12 installed!" -ForegroundColor Green
        Remove-Item $pyInstaller -Force
        
        # Determine the fresh python command (avoid broken aliases)
        $freshPython = "python"
        if (Test-Path "C:\Program Files\Python312\python.exe") {
            $freshPython = "C:\Program Files\Python312\python.exe"
        } elseif (Test-Path "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe") {
            $freshPython = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"
        }

        Write-Host "[*] Installing Face Swap dependencies using: $freshPython" -ForegroundColor Yellow
        & $freshPython -m pip install --upgrade pip
        & $freshPython -m pip install insightface onnxruntime opencv-python gdown
        
        Download-FaceSwapModel -pythonExec $freshPython -destDir $ScriptDir

    } catch {
        Write-Host "[-] Failed to install Python: $_" -ForegroundColor Red
        Write-Host "    Please install Python 3.12 manually from https://python.org" -ForegroundColor Yellow
    }
}

Write-Host ""

# STEP 2: Prepare Folders
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "STEP 2: Preparing Folders" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan

$requiredFolders = @(
    "accounts",
    "videos",
    "photos",
    "logs",
    "logs\scheduler",
    "logs\telegram",
    "logs\maintenance",
    "logs\error",
    "config"
)

foreach ($folder in $requiredFolders) {
    if (-not (Test-Path $folder)) {
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
        Write-Host "[+] Created: $folder" -ForegroundColor Green
    } else {
        Write-Host "[*] Exists:  $folder" -ForegroundColor Gray
    }
}

Write-Host ""

# STEP 3: Install NPM Dependencies
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "STEP 3: Installing NPM Dependencies" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan

if (Test-Path "package.json") {
    Write-Host "[*] Installing dependencies with npm install..." -ForegroundColor Yellow
    npm install
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "[+] Dependencies installed successfully!" -ForegroundColor Green
    } else {
        Write-Host "[-] npm install failed!" -ForegroundColor Red
        Write-Host "    Please check your internet connection and try again" -ForegroundColor Yellow
        Read-Host "Press Enter to exit"
        exit 1
    }
} else {
    Write-Host "[-] package.json not found!" -ForegroundColor Red
    Write-Host "    Make sure you're in the correct directory" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""

# Install Browser (Playwright + Brave Check)
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "STEP 4: Installing Browser Engine" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan

Write-Host "[*] Checking for Brave Browser..." -ForegroundColor Yellow
$bravePaths = @(
    "${env:ProgramFiles}\BraveSoftware\Brave-Browser\Application\brave.exe",
    "${env:ProgramFiles(x86)}\BraveSoftware\Brave-Browser\Application\brave.exe",
    "${env:LocalAppData}\BraveSoftware\Brave-Browser\Application\brave.exe"
)

$braveFound = $false
foreach ($path in $bravePaths) {
    if (Test-Path $path) {
        Write-Host "[+] Brave Browser found at: $path" -ForegroundColor Green
        $braveFound = $true
        break
    }
}

if (-not $braveFound) {
    Write-Host "[!] Brave Browser NOT found!" -ForegroundColor Red
    Write-Host "    FBPro Blaster requires Brave for aggressive ad-blocking." -ForegroundColor Yellow
    Write-Host "    Downloading Brave Installer..." -ForegroundColor Cyan
    $braveUrl = "https://laptop-updates.brave.com/latest/winx64"
    $braveInstaller = "$env:TEMP\BraveBrowserSetup.exe"
    try {
        Invoke-WebRequest -Uri $braveUrl -OutFile $braveInstaller -UseBasicParsing
        Write-Host "[*] Running Brave Installer... Please complete the installation." -ForegroundColor Yellow
        Start-Process -FilePath $braveInstaller -Wait
        Write-Host "[+] Brave installation attempt finished." -ForegroundColor Green
    } catch {
        Write-Host "[-] Failed to download Brave automatically. Please install from https://brave.com" -ForegroundColor Red
    }
}

Write-Host "[*] Installing Playwright Chromium dependencies..." -ForegroundColor Yellow
npx playwright install chromium

if ($LASTEXITCODE -eq 0) {
    Write-Host "[+] Playwright core installed successfully!" -ForegroundColor Green
} else {
    Write-Host "[-] Playwright installation may have issues, but continuing..." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  Setup completed successfully!" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""

# Show next steps based on browser choice
Write-Host "Browser Engine: $($script:BROWSER_ENGINE)" -ForegroundColor Cyan
Write-Host ""

Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Configure your accounts in the 'accounts' folder" -ForegroundColor White
Write-Host "  2. Brave adblock warm-up runs automatically and globally on first bot launch" -ForegroundColor Green
Write-Host "  3. Run 'node bot/executor run uploadreels account1' to start" -ForegroundColor White
Write-Host "  4. Visit 'brave://components' if adblock is not working" -ForegroundColor gray

Write-Host ""
Write-Host "For help, visit: https://github.com/scwhhhhg/fbpro-blaster" -ForegroundColor Cyan
Write-Host ""

Read-Host "Press Enter to exit"
