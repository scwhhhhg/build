# FacebookPro Blaster - Docker Setup Script (Enhanced)
# Production-ready Docker Compose deployment

param(
    [switch]$SkipBuild,
    [switch]$NoHealthCheck,
    [string]$EnvFile = ".env"
)

$ErrorActionPreference = "Stop"

# Colors for output
function Write-Success { param($msg) Write-Host "✅ $msg" -ForegroundColor Green }
function Write-Info { param($msg) Write-Host "ℹ️  $msg" -ForegroundColor Cyan }
function Write-Warning { param($msg) Write-Host "⚠️  $msg" -ForegroundColor Yellow }
function Write-ErrorExit { param($msg) Write-Host "❌ $msg" -ForegroundColor Red; exit 1 }

Write-Info "FacebookPro Blaster - Docker Setup"
Write-Info "==================================`n"

# 1. Check Docker installation
Write-Info "Checking Docker installation..."
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-ErrorExit "Docker is not installed. Please install Docker Desktop from https://docker.com"
}
Write-Success "Docker found: $(docker --version)"

# 2. Check Docker Compose (v2 plugin or v1 standalone)
Write-Info "Checking Docker Compose..."
$composeVersion = ""
$composeCommand = ""

# Try Docker Compose V2 plugin first
$composeCheck = docker compose version 2>$null
if ($LASTEXITCODE -eq 0) {
    $composeCommand = "docker compose"
    $composeVersion = $composeCheck
} 
# Try Docker Compose V1 as fallback
elseif (Get-Command docker-compose -ErrorAction SilentlyContinue) {
    $composeCommand = "docker-compose"
    $composeVersion = docker-compose --version
} 
else {
    Write-ErrorExit "Docker Compose is not installed. Please install Docker Compose plugin or docker-compose v1"
}

Write-Success "Docker Compose found: $composeVersion"

# 3. Find docker-compose.yml
Write-Info "Locating docker-compose.yml..."
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
$composeDir = $root
$composePath = Join-Path $root "docker-compose.yml"

if (-not (Test-Path $composePath)) {
    $composeDir = Join-Path $root "docker-deploy"
    $composePath = Join-Path $composeDir "docker-compose.yml"
}

if (-not (Test-Path $composePath)) {
    Write-ErrorExit "docker-compose.yml not found in root or docker-deploy directory"
}
Write-Success "Found docker-compose.yml at: $composePath"

# 4. Validate environment file
Write-Info "Validating environment configuration..."
$envPath = Join-Path $root $EnvFile
$exampleEnvPath = Join-Path $root ".env.example"

if (-not (Test-Path $envPath)) {
    if (Test-Path $exampleEnvPath) {
        Write-Warning "Environment file (.env) not found. Copying from .env.example..."
        Copy-Item $exampleEnvPath $envPath
        Write-Warning "Please edit .env file with your configuration before continuing!"
        Write-Info "Required variables:"
        Write-Info "  - SUPABASE_URL"
        Write-Info "  - SUPABASE_ANON_KEY (or CLOUDDB_URL, CLOUDDB_ANON_KEY)"
        Write-Info "  - TELEGRAM_BOT_TOKEN (optional)"
        Write-Info "  - TELEGRAM_CHAT_ID (optional)"
        
        # Check if running in non-interactive mode
        if ([Environment]::GetCommandLineArgs() -contains '--NonInteractive') {
            Write-ErrorExit "Non-interactive mode requires existing .env file"
        }
        
        $continue = Read-Host "Continue anyway? (y/N)"
        if ($continue -ne 'y' -and $continue -ne 'Y') {
            exit 0
        }
    } else {
        Write-ErrorExit "No .env or .env.example found"
    }
} else {
    # Validate required variables
    $envContent = Get-Content $envPath -Raw
    $hasRequiredVars = $envContent -match "SUPABASE_URL|CLOUDDB_URL"
    $hasAnonKey = $envContent -match "SUPABASE_ANON_KEY|CLOUDDB_ANON_KEY"
    
    if (-not ($hasRequiredVars -and $hasAnonKey)) {
        Write-Warning "Environment file may be missing required variables"
        Write-Info "Required: SUPABASE_URL, SUPABASE_ANON_KEY (or CLOUDDB_URL, CLOUDDB_ANON_KEY)"
    } else {
        Write-Success "Environment configuration valid"
    }
}

# 5. Check port conflicts
Write-Info "Checking port conflicts..."
$portsToCheck = @(3000, 3001, 5432, 6379, 8080, 9229)
$conflicts = @()
foreach ($port in $portsToCheck) {
    $connection = Test-NetConnection -ComputerName localhost -Port $port -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
    if ($connection.TcpTestSucceeded) {
        $conflicts += $port
    }
}

if ($conflicts.Count -gt 0) {
    Write-Warning "Ports in use: $($conflicts -join ', ')"
    Write-Info "This may cause container startup failures. Stop conflicting services or modify docker-compose.yml ports."
}

# 6. Stop existing containers
Write-Info "Stopping any existing containers..."
Set-Location $composeDir
if ($composeCommand -eq "docker compose") {
    docker compose down --remove-orphans 2>$null | Out-Null
} else {
    docker-compose down --remove-orphans 2>$null | Out-Null
}
Write-Success "Previous containers stopped"

# 7. Start containers
Write-Info "Starting containers..."

if ($SkipBuild) {
    Write-Info "Skipping build (--skip-build flag detected)"
    if ($composeCommand -eq "docker compose") {
        docker compose up -d
    } else {
        docker-compose up -d
    }
} else {
    Write-Info "Building and starting containers (this may take a few minutes)..."
    if ($composeCommand -eq "docker compose") {
        docker compose up -d --build
    } else {
        docker-compose up -d --build
    }
}

if ($LASTEXITCODE -ne 0) {
    Write-ErrorExit "Failed to start containers. Check logs with: docker compose logs"
}

Write-Success "Containers started successfully"

# 8. Health check (optional)
if (-not $NoHealthCheck) {
    Write-Info "Performing health check..."
    Start-Sleep -Seconds 3
    
    $healthCheckPassed = $false
    $maxAttempts = 10
    $attempt = 0
    
    while ($attempt -lt $maxAttempts -and -not $healthCheckPassed) {
        $attempt++
        
        # Check container status
        if ($composeCommand -eq "docker compose") {
            $containers = docker compose ps --format json 2>$null | ConvertFrom-Json
        } else {
            $containers = docker-compose ps --format json 2>$null | ConvertFrom-Json
        }
        
        # Check if all containers are running
        $allRunning = $true
        foreach ($container in $containers) {
            if ($container.State -ne "running") {
                $allRunning = $false
                break
            }
        }
        
        if ($allRunning -and $containers.Count -gt 0) {
            $healthCheckPassed = $true
            break
        }
        
        Write-Info "Waiting for containers to be ready... ($attempt/$maxAttempts)"
        Start-Sleep -Seconds 3
    }
    
    if ($healthCheckPassed) {
        Write-Success "All containers are running"
    } else {
        Write-Warning "Some containers may not be ready. Check status with: docker compose ps"
    }
}

# 9. Show container status
Write-Info "Container Status:"
Write-Info "=================="
if ($composeCommand -eq "docker compose") {
    docker compose ps
} else {
    docker-compose ps
}

# 10. Show helpful information
Write-Info ""
Write-Info "Deployment Complete!"
Write-Info "====================="
Write-Info "View logs: docker compose logs -f"
Write-Info "Stop containers: docker compose down"
Write-Info "Rebuild: docker compose up -d --build"

# List available services
Write-Info ""
Write-Info "Available services:"
if ($composeCommand -eq "docker compose") {
    docker compose ps --services
} else {
    docker-compose ps --services
}
