import sys
import cv2
import insightface
from insightface.app import FaceAnalysis
import numpy as np
import os
import traceback

def swap_face(source_path, target_path, output_path):
    try:
        # Initialize FaceAnalysis
        print("Initializing FaceAnalysis...")
        app = FaceAnalysis(name='buffalo_l')
        # Use ctx_id=-1 for CPU (most compatible across VPS/Home PCs)
        app.prepare(ctx_id=-1, det_size=(640, 640), det_thresh=0.3)
        
        # Search for model in common locations (NO DOWNLOADS)
        model_name = 'inswapper_128.onnx'
        model_path = None
        
        # Check explicit relative paths first
        possible_paths = [
            os.path.join(os.getcwd(), 'bot', model_name),
            os.path.join(os.path.dirname(__file__), model_name),
            os.path.join(os.getcwd(), model_name),
        ]
        
        for p in possible_paths:
            if os.path.exists(p):
                model_path = p
                print(f"Found model at: {p}")
                break
        
        if not model_path:
            raise FileNotFoundError(f"Model {model_name} not found")
            
        print(f"Loading local model: {model_path}")
        swapper = insightface.model_zoo.get_model(model_path, download=False)

        # Read images
        print(f"Reading images... Target: {target_path}")
        img_source = cv2.imread(source_path)
        img_target = cv2.imread(target_path)

        if img_source is None:
            print(f"Error: Source image not found or invalid: {source_path}")
            return False
            
        if img_target is None:
            print(f"Error: Target image not found or invalid: {target_path}")
            return False

        # STEP 1: Upscale target image
        h_orig, w_orig = img_target.shape[:2]
        print(f"Original image size: {w_orig}x{h_orig}")
        
        target_size = 1024
        if w_orig < target_size or h_orig < target_size:
            scale_factor = target_size / min(w_orig, h_orig)
            new_w = int(w_orig * scale_factor)
            new_h = int(h_orig * scale_factor)
            img_target = cv2.resize(img_target, (new_w, new_h), interpolation=cv2.INTER_LANCZOS4)
            print(f"Upscaled to: {new_w}x{new_h}")
        
        h, w = img_target.shape[:2]
        
        # STEP 2: Face detection on target
        print("Detecting face in target image...")
        # Pre-process image to improve detection on AI-generated faces
        lab = cv2.cvtColor(img_target, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        l_enhanced = clahe.apply(l)
        lab_enhanced = cv2.merge([l_enhanced, a, b])
        img_enhanced = cv2.cvtColor(lab_enhanced, cv2.COLOR_LAB2BGR)
        
        detection_configs = [
            {'img': img_enhanced, 'thresh': 0.3},
            {'img': img_target, 'thresh': 0.3},
            {'img': img_enhanced, 'thresh': 0.1},
        ]
        
        target_faces = []
        for config in detection_configs:
            app.prepare(ctx_id=-1, det_size=(640, 640), det_thresh=config['thresh'])
            target_faces = app.get(config['img'])
            if len(target_faces) > 0:
                print(f"[OK] Found {len(target_faces)} face(s) in target (thresh: {config['thresh']})")
                break
        
        if len(target_faces) == 0:
            print("Error: No face detected in target image after all attempts")
            return False
        
        # Get source face
        print(f"Detecting face in source image: {source_path}")
        
        # 1. Sharpen source image to help identity extraction
        source_kernel = np.array([[0,-1,0], [-1,5,-1], [0,-1,0]])
        img_source_sharp = cv2.filter2D(img_source, -1, source_kernel)
        
        # 2. Fast detection loop
        source_faces = []
        for det_thresh in [0.5, 0.3, 0.1]:
            app.prepare(ctx_id=-1, det_size=(640, 640), det_thresh=det_thresh)
            source_faces = app.get(img_source_sharp)
            if len(source_faces) > 0:
                print(f"[OK] Found face in source (thresh: {det_thresh})")
                break

        # Fallback to enhanced if still nothing
        if len(source_faces) == 0:
            print("Trying enhanced source detection...")
            source_lab = cv2.cvtColor(img_source, cv2.COLOR_BGR2LAB)
            sl, sa, sb = cv2.split(source_lab)
            s_clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
            source_lab_enhanced = cv2.merge([s_clahe.apply(sl), sa, sb])
            img_source_enhanced = cv2.cvtColor(source_lab_enhanced, cv2.COLOR_LAB2BGR)
            
            app.prepare(ctx_id=-1, det_size=(640, 640), det_thresh=0.05)
            source_faces = app.get(img_source_enhanced)
            if len(source_faces) > 0:
                print("[OK] Found face in enhanced source")

        if len(source_faces) == 0:
            print("Error: No face detected in source image")
            return False

        # Sort by size and take largest
        source_face = sorted(source_faces, key=lambda x: (x.bbox[2]-x.bbox[0])*(x.bbox[3]-x.bbox[1]))[-1]

        # STEP 3: Face swap
        print("Performing face swap...")
        result_img = img_target.copy()
        
        for target_face in target_faces:
            print("Applying swap for a detected face...")
            result_img = swapper.get(result_img, target_face, source_face, paste_back=True)
        
        print("Face swap logic finished")

        # STEP 4: Face restoration with GFPGAN
        restoration_success = False
        try:
            print("Preparing face restoration...")
            import sys
            import types
            import torchvision.transforms.functional as TF
            mock_ft = types.ModuleType('functional_tensor')
            for attr in dir(TF):
                if not attr.startswith('__'): setattr(mock_ft, attr, getattr(TF, attr))
            sys.modules['torchvision.transforms.functional_tensor'] = mock_ft
            
            from gfpgan import GFPGANer
            print("Initializing GFPGAN restorer (CPU mode)...")
            gfpgan_model_path = 'https://github.com/TencentARC/GFPGAN/releases/download/v1.3.0/GFPGANv1.3.pth'
            restorer = GFPGANer(
                model_path=gfpgan_model_path,
                upscale=1,
                arch='clean',
                channel_multiplier=2,
                bg_upsampler=None
            )
            
            print("Enhancing faces with GFPGAN...")
            _, _, restored_img = restorer.enhance(
                result_img,
                has_aligned=False,
                only_center_face=False,
                paste_back=True,
                weight=0.4
            )
            
            if restored_img is not None:
                result_img = restored_img
                restoration_success = True
                print("[OK] GFPGAN restoration successful")
            else:
                print("[WARN] GFPGAN returned no image")
                
        except Exception as e_gfpgan:
            print(f"[WARN] Restoration skipped: {str(e_gfpgan)}")

        # Final Post-Processing
        try:
            print("Finalizing global texture...")
            result_img = cv2.convertScaleAbs(result_img, alpha=1.05, beta=2)
            kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            sharpened = cv2.filter2D(result_img, -1, kernel)
            result_img = cv2.addWeighted(result_img, 0.9, sharpened, 0.1, 0)
            
            noise = np.random.randint(0, 5, result_img.shape, dtype='uint8')
            result_img = cv2.add(result_img, noise)
            print("[OK] Final processing complete")
        except:
            pass

        # Save result
        print(f"Saving final image to: {output_path}")
        cv2.imwrite(output_path, result_img)
        print("Check: Output file exists:", os.path.exists(output_path))
        
        return True

    except Exception as e:
        print(f"CRITICAL ERROR in FaceSwap: {str(e)}")
        print(traceback.format_exc())
        return False

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python faceswap.py <source> <target> <output>")
        sys.exit(1)
        
    success = swap_face(sys.argv[1], sys.argv[2], sys.argv[3])
    if success:
        print("FaceSwap.py: [SUCCESS]")
        sys.exit(0)
    else:
        print("FaceSwap.py: [FAILED]")
        sys.exit(1)
