#!/usr/bin/env bash
# FacebookPro Blaster - Docker Setup Script (Enhanced)
# Production-ready Docker Compose deployment

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Parse arguments
SKIP_BUILD=false
NO_HEALTH_CHECK=false
ENV_FILE=".env"

while [[ $# -gt 0 ]]; do
    case $1 in
        --skip-build)
            SKIP_BUILD=true
            shift
            ;;
        --no-health-check)
            NO_HEALTH_CHECK=true
            shift
            ;;
        --env)
            ENV_FILE="$2"
            shift 2
            ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --skip-build       Skip building images, just start containers"
            echo "  --no-health-check Skip health check after startup"
            echo "  --env FILE        Environment file (default: .env)"
            echo "  --help, -h        Show this help message"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

# Helper functions
log_success() { echo -e "${GREEN}✅ $1${NC}"; }
log_info() { echo -e "${CYAN}ℹ️  $1${NC}"; }
log_warning() { echo -e "${YELLOW}⚠️  $1${NC}"; }
log_error() { echo -e "${RED}❌ $1${NC}"; exit 1; }

echo ""
log_info "FacebookPro Blaster - Docker Setup"
log_info "=================================="
echo ""

# 1. Check Docker installation
log_info "Checking Docker installation..."
if ! command -v docker &> /dev/null; then
    log_error "Docker is not installed. Please install Docker Desktop from https://docker.com"
fi
log_success "Docker found: $(docker --version)"

# 2. Check Docker Compose (v2 plugin or v1 standalone)
log_info "Checking Docker Compose..."
COMPOSE_VERSION=""
COMPOSE_COMMAND=""

# Try Docker Compose V2 plugin first
if docker compose version &> /dev/null; then
    COMPOSE_COMMAND="docker compose"
    COMPOSE_VERSION=$(docker compose version)
# Try Docker Compose V1 as fallback
elif command -v docker-compose &> /dev/null; then
    COMPOSE_COMMAND="docker-compose"
    COMPOSE_VERSION=$(docker-compose --version)
else
    log_error "Docker Compose is not installed. Please install Docker Compose plugin or docker-compose v1"
fi

log_success "Docker Compose found: $COMPOSE_VERSION"

# 3. Find docker-compose.yml
log_info "Locating docker-compose.yml..."
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
COMPOSE_DIR="$ROOT_DIR"
COMPOSE_PATH="$ROOT_DIR/docker-compose.yml"

if [ ! -f "$COMPOSE_PATH" ]; then
    COMPOSE_DIR="$ROOT_DIR/docker-deploy"
    COMPOSE_PATH="$COMPOSE_DIR/docker-compose.yml"
fi

if [ ! -f "$COMPOSE_PATH" ]; then
    log_error "docker-compose.yml not found in root or docker-deploy directory"
fi
log_success "Found docker-compose.yml at: $COMPOSE_PATH"

# 4. Validate environment file
log_info "Validating environment configuration..."
ENV_PATH="$ROOT_DIR/$ENV_FILE"
EXAMPLE_ENV_PATH="$ROOT_DIR/.env.example"

if [ ! -f "$ENV_PATH" ]; then
    if [ -f "$EXAMPLE_ENV_PATH" ]; then
        log_warning "Environment file (.env) not found. Copying from .env.example..."
        cp "$EXAMPLE_ENV_PATH" "$ENV_PATH"
        log_warning "Please edit .env file with your configuration before continuing!"
        log_info "Required variables:"
        log_info "  - SUPABASE_URL"
        log_info "  - SUPABASE_ANON_KEY (or CLOUDDB_URL, CLOUDDB_ANON_KEY)"
        log_info "  - TELEGRAM_BOT_TOKEN (optional)"
        log_info "  - TELEGRAM_CHAT_ID (optional)"
        
        if [ -t 0 ]; then
            read -p "Continue anyway? (y/N) " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                exit 0
            fi
        else
            log_error "Non-interactive mode requires existing .env file"
        fi
    else
        log_error "No .env or .env.example found"
    fi
else
    # Validate required variables
    if grep -qE "SUPABASE_URL|CLOUDDB_URL" "$ENV_PATH" && \
       grep -qE "SUPABASE_ANON_KEY|CLOUDDB_ANON_KEY" "$ENV_PATH"; then
        log_success "Environment configuration valid"
    else
        log_warning "Environment file may be missing required variables"
        log_info "Required: SUPABASE_URL, SUPABASE_ANON_KEY (or CLOUDDB_URL, CLOUDDB_ANON_KEY)"
    fi
fi

# 5. Check port conflicts
log_info "Checking port conflicts..."
PORTS=(3000 3001 5432 6379 8080 9229)
CONFLICTS=()

for port in "${PORTS[@]}"; do
    if timeout 1 bash -c "echo >/dev/tcp/localhost/$port" 2>/dev/null; then
        CONFLICTS+=("$port")
    fi
done

if [ ${#CONFLICTS[@]} -gt 0 ]; then
    log_warning "Ports in use: ${CONFLICTS[*]}"
    log_info "This may cause container startup failures. Stop conflicting services or modify docker-compose.yml ports."
fi

# 6. Stop existing containers
log_info "Stopping any existing containers..."
cd "$COMPOSE_DIR"
$COMPOSE_COMMAND down --remove-orphans 2>/dev/null || true
log_success "Previous containers stopped"

# Cleanup on error
trap 'if [ $? -ne 0 ]; then
    log_warning "Deployment failed. Showing logs:"
    $COMPOSE_COMMAND logs --tail=50
fi' ERR

# 7. Start containers
log_info "Starting containers..."

if [ "$SKIP_BUILD" = true ]; then
    log_info "Skipping build (--skip-build flag detected)"
    $COMPOSE_COMMAND up -d
else
    log_info "Building and starting containers (this may take a few minutes)..."
    $COMPOSE_COMMAND up -d --build
fi

if [ $? -ne 0 ]; then
    log_error "Failed to start containers. Check logs with: $COMPOSE_COMMAND logs"
fi

log_success "Containers started successfully"

# 8. Health check (optional)
if [ "$NO_HEALTH_CHECK" = false ]; then
    log_info "Performing health check..."
    sleep 3
    
    HEALTH_CHECK_PASSED=false
    MAX_ATTEMPTS=10
    ATTEMPT=0
    
    while [ $ATTEMPT -lt $MAX_ATTEMPTS ] && [ "$HEALTH_CHECK_PASSED" = false ]; do
        ((ATTEMPT++))
        
        # Check container status
        CONTAINERS=$($COMPOSE_COMMAND ps --format json 2>/dev/null)
        
        if [ -z "$CONTAINERS" ]; then
            # Try alternative format
            CONTAINERS=$($COMPOSE_COMMAND ps 2>/dev/null)
        fi
        
        # Simple check - if no error, consider it healthy
        if [ $? -eq 0 ]; then
            HEALTH_CHECK_PASSED=true
            break
        fi
        
        log_info "Waiting for containers to be ready... ($ATTEMPT/$MAX_ATTEMPTS)"
        sleep 3
    done
    
    if [ "$HEALTH_CHECK_PASSED" = true ]; then
        log_success "All containers are running"
    else
        log_warning "Some containers may not be ready. Check status with: $COMPOSE_COMMAND ps"
    fi
fi

# 9. Show container status
log_info "Container Status:"
log_info "=================="
$COMPOSE_COMMAND ps

# 10. Show helpful information
echo ""
log_info "Deployment Complete!"
log_info "====================="
log_info "View logs: $COMPOSE_COMMAND logs -f"
log_info "Stop containers: $COMPOSE_COMMAND down"
log_info "Rebuild: $COMPOSE_COMMAND up -d --build"

# List available services
log_info ""
log_info "Available services:"
$COMPOSE_COMMAND ps --services
